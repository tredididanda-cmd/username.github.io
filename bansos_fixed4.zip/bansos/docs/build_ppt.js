const pptxgen = require("pptxgenjs");

const pptx = new pptxgen();
pptx.author = "ChatGPT";
pptx.layout = "LAYOUT_WIDE";

function addTitleSlide() {
  const slide = pptx.addSlide();
  slide.addText("Sistem Pendataan\ndan Distribusi Bantuan Sosial", {
    x: 0.8, y: 1.2, w: 11.7, h: 1.3,
    fontFace: "Calibri", fontSize: 40, bold: true, align: "center"
  });
  slide.addText("Ringkasan Proyek (Web App + Database)", {
    x: 1.5, y: 2.8, w: 10.3, h: 0.6,
    fontFace: "Calibri", fontSize: 20, align: "center"
  });
  slide.addText("Demo: Express + MySQL + Bootstrap", {
    x: 1.5, y: 3.5, w: 10.3, h: 0.4,
    fontFace: "Calibri", fontSize: 16, color: "666666", align: "center"
  });
}

function addAgenda() {
  const slide = pptx.addSlide();
  slide.addText("Agenda", { x: 0.8, y: 0.6, w: 12, h: 0.6, fontSize: 30, bold: true });
  const items = [
    "Latar belakang & tujuan",
    "Fitur utama",
    "Arsitektur sistem",
    "Desain database",
    "Alur kerja petugas",
    "Deployment & rencana pengembangan"
  ];
  slide.addText(items.map(i => `• ${i}`).join("\n"), { x: 1.2, y: 1.5, w: 11, h: 4.5, fontSize: 20, lineSpacingMultiple: 1.2 });
}

function addFeatures() {
  const slide = pptx.addSlide();
  slide.addText("Fitur Utama", { x: 0.8, y: 0.6, w: 12, h: 0.6, fontSize: 30, bold: true });
  const left = [
    "Login Admin/Petugas",
    "CRUD Data Penerima (NIK unik)",
    "Pencatatan Penyaluran (tanggal, status, catatan)"
  ];
  const right = [
    "Item Bantuan (jenis, jumlah, satuan)",
    "Master data: sumber dana, pendamping, lokasi",
    "Dashboard ringkas & halaman detail record"
  ];
  slide.addText(left.map(i=>`• ${i}`).join("\n"), { x: 1.0, y: 1.5, w: 6.2, h: 4.5, fontSize: 20 });
  slide.addText(right.map(i=>`• ${i}`).join("\n"), { x: 7.0, y: 1.5, w: 6.2, h: 4.5, fontSize: 20 });
}

function addArchitecture() {
  const slide = pptx.addSlide();
  slide.addText("Arsitektur Sistem", { x: 0.8, y: 0.6, w: 12, h: 0.6, fontSize: 30, bold: true });
  slide.addShape(pptx.ShapeType.roundRect, { x: 1.0, y: 2.0, w: 3.5, h: 1.0 });
  slide.addText("Browser\n(Petugas/Admin)", { x: 1.0, y: 2.05, w: 3.5, h: 1.0, align:"center", fontSize: 16 });

  slide.addShape(pptx.ShapeType.roundRect, { x: 5.0, y: 2.0, w: 3.5, h: 1.0 });
  slide.addText("Server\nExpress + EJS", { x: 5.0, y: 2.05, w: 3.5, h: 1.0, align:"center", fontSize: 16 });

  slide.addShape(pptx.ShapeType.roundRect, { x: 9.0, y: 2.0, w: 3.5, h: 1.0 });
  slide.addText("Database\nMySQL/MariaDB", { x: 9.0, y: 2.05, w: 3.5, h: 1.0, align:"center", fontSize: 16 });

  slide.addShape(pptx.ShapeType.line, { x: 4.55, y: 2.5, w: 0.45, h: 0, line: { width: 2 } });
  slide.addShape(pptx.ShapeType.line, { x: 8.55, y: 2.5, w: 0.45, h: 0, line: { width: 2 } });

  slide.addText("• Server-side rendering (mudah deploy)\n• Session auth\n• Query parameterized\n• Normalisasi data item bantuan", { x: 1.0, y: 3.5, w: 11.5, h: 2.5, fontSize: 18 });
}

function addDatabase() {
  const slide = pptx.addSlide();
  slide.addText("Desain Database (Ringkas)", { x: 0.8, y: 0.6, w: 12, h: 0.6, fontSize: 30, bold: true });
  const bullets = [
    "recipients (NIK unik)",
    "assistance_records (header penyaluran)",
    "assistance_items (detail item bantuan)",
    "master: assistance_types, funding_sources, companions, distribution_locations",
    "users (admin/petugas)"
  ];
  slide.addText(bullets.map(b=>`• ${b}`).join("\n"), { x: 1.0, y: 1.5, w: 11.5, h: 4.8, fontSize: 20 });
  slide.addText("Catatan: normalisasi memudahkan rekap & menghindari kolom bantuan berulang.", { x: 1.0, y: 6.2, w: 11.5, h: 0.5, fontSize: 16, color: "666666" });
}

function addWorkflow() {
  const slide = pptx.addSlide();
  slide.addText("Alur Kerja Petugas", { x: 0.8, y: 0.6, w: 12, h: 0.6, fontSize: 30, bold: true });
  const steps = [
    "1) Login",
    "2) Input/cek data penerima (NIK)",
    "3) Buat record penyaluran",
    "4) Isi item bantuan (maks 3), sumber dana, pendamping, lokasi",
    "5) Update status: MENUNGGU → SEDANG_BAGI → SELESAI",
    "6) Lihat dashboard & detail record untuk rekap"
  ];
  slide.addText(steps.map(s=>`• ${s}`).join("\n"), { x: 1.0, y: 1.5, w: 11.5, h: 5.5, fontSize: 20 });
}

function addClosing() {
  const slide = pptx.addSlide();
  slide.addText("Rencana Pengembangan", { x: 0.8, y: 0.6, w: 12, h: 0.6, fontSize: 30, bold: true });
  slide.addText(
    "• Export laporan (PDF/Excel)\n• Role & audit log lebih detail\n• Validasi NIK (panjang/format)\n• Integrasi peta lokasi penyaluran\n• Mode offline/backup",
    { x: 1.0, y: 1.5, w: 11.5, h: 4.0, fontSize: 20 }
  );
  slide.addText("Terima kasih", { x: 0.8, y: 6.3, w: 12, h: 0.6, fontSize: 28, bold: true, align: "center" });
}

addTitleSlide();
addAgenda();
addFeatures();
addArchitecture();
addDatabase();
addWorkflow();
addClosing();

pptx.writeFile({ fileName: "/mnt/data/bansos_project/docs/Presentasi_Sistem_Bansos.pptx" });
