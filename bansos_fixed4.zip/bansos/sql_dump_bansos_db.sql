-- SQL Dump: Sistem Pendataan dan Distribusi Bantuan Sosial
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;
DROP DATABASE IF EXISTS bansos_db;
CREATE DATABASE bansos_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bansos_db;

-- Users (admin/petugas)
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('ADMIN','PETUGAS') NOT NULL DEFAULT 'PETUGAS',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

DROP TABLE IF EXISTS recipients;
CREATE TABLE recipients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nik VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(30),
  address TEXT,
  kelurahan VARCHAR(100),
  kecamatan VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

DROP TABLE IF EXISTS assistance_types;
CREATE TABLE assistance_types (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

DROP TABLE IF EXISTS funding_sources;
CREATE TABLE funding_sources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB;

DROP TABLE IF EXISTS companions;
CREATE TABLE companions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE
) ENGINE=InnoDB;

DROP TABLE IF EXISTS distribution_locations;
CREATE TABLE distribution_locations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL UNIQUE
) ENGINE=InnoDB;

DROP TABLE IF EXISTS assistance_records;
CREATE TABLE assistance_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  record_date DATE NOT NULL,
  recipient_id INT NOT NULL,
  status ENUM('MENUNGGU','SEDANG_BAGI','SELESAI') NOT NULL DEFAULT 'MENUNGGU',
  notes TEXT,
  funding_source_1_id INT NULL,
  funding_source_2_id INT NULL,
  companion_1_id INT NULL,
  companion_2_id INT NULL,
  location_1_id INT NULL,
  location_2_id INT NULL,
  input_by_user_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (recipient_id) REFERENCES recipients(id),
  FOREIGN KEY (funding_source_1_id) REFERENCES funding_sources(id),
  FOREIGN KEY (funding_source_2_id) REFERENCES funding_sources(id),
  FOREIGN KEY (companion_1_id) REFERENCES companions(id),
  FOREIGN KEY (companion_2_id) REFERENCES companions(id),
  FOREIGN KEY (location_1_id) REFERENCES distribution_locations(id),
  FOREIGN KEY (location_2_id) REFERENCES distribution_locations(id),
  FOREIGN KEY (input_by_user_id) REFERENCES users(id)
) ENGINE=InnoDB;

DROP TABLE IF EXISTS assistance_items;
CREATE TABLE assistance_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  record_id INT NOT NULL,
  assistance_type_id INT NOT NULL,
  qty DECIMAL(18,3) NULL,
  unit VARCHAR(40) NULL,
  FOREIGN KEY (record_id) REFERENCES assistance_records(id) ON DELETE CASCADE,
  FOREIGN KEY (assistance_type_id) REFERENCES assistance_types(id)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS=1;
INSERT INTO `users` (`username`, `full_name`, `password_hash`, `role`) VALUES
  ('admin', 'Administrator', '$2b$10$KZcWrf5T0QwcvhXoK3uS5OX0M8CEq9h6FJ1TgY/5yVf8C1b0D7xZe', 'ADMIN'),
  ('joko', 'Joko', '$2b$10$hQFIK4lYb/2u2oE4z2o1suE6GZzj2e7gVbJ0dUe9JdJwVwQZr6t2S', 'PETUGAS'),
  ('lina', 'Lina', '$2b$10$hQFIK4lYb/2u2oE4z2o1suE6GZzj2e7gVbJ0dUe9JdJwVwQZr6t2S', 'PETUGAS'),
  ('tono', 'Tono', '$2b$10$hQFIK4lYb/2u2oE4z2o1suE6GZzj2e7gVbJ0dUe9JdJwVwQZr6t2S', 'PETUGAS'),
  ('dedi', 'Dedi', '$2b$10$hQFIK4lYb/2u2oE4z2o1suE6GZzj2e7gVbJ0dUe9JdJwVwQZr6t2S', 'PETUGAS');
INSERT INTO `assistance_types` (`name`) VALUES
  ('Beras'),
  ('Gula Pasir'),
  ('Minyak Goreng'),
  ('Paket Sembako'),
  ('Uang Tunai');
INSERT INTO `funding_sources` (`name`) VALUES
  ('APBD Kota'),
  ('CSR Perusahaan'),
  ('Donasi Komunitas'),
  ('Donasi LSM'),
  ('Donasi Warga');
INSERT INTO `companions` (`name`) VALUES
  ('Andi'),
  ('Bunga'),
  ('Rina');
INSERT INTO `distribution_locations` (`name`) VALUES
  ('Aula Kecamatan Tampan'),
  ('Halte BRPS'),
  ('Halte Srikandi'),
  ('Kantor Kecamatan Marpoyan Damai'),
  ('Kantor Lurah Tangkerang Labuai'),
  ('Masjid Al-Ikhlas'),
  ('Pos RW 02'),
  ('Pos RW 03'),
  ('Posko Bantuan Simpang Tiga'),
  ('Posko RW 04'),
  ('Rumah Faisal'),
  ('Rumah Hani');
INSERT INTO `recipients` (`nik`, `name`, `phone`, `address`, `kelurahan`, `kecamatan`) VALUES
  ('140101010101', 'Andi Pratama', '0812-7301', 'Jl. Melur No. 10', 'Tangkerang Labuai', 'Bukit Raya'),
  ('140101020202', 'Bunga Cahyani', '0812-7302', 'Gg. Mawar No. 5', 'Sidomulyo Barat', 'Tampan'),
  ('140101030303', 'Candra Wijaya', '0812-7303', 'Jl. Garuda No. 21', 'Labuh Baru Timur', 'Payung Sekaki'),
  ('140101040404', 'Desti Rahma', '0812-7304', 'Jl. Durian III No. 3', 'Wonorejo', 'Marpoyan Damai'),
  ('140101050505', 'Eko Putra', '0812-7305', 'Jl. Dahlia No. 8', 'Simpang Tiga', 'Bukit Raya'),
  ('140101060606', 'Faisal Ahmad', '0812-7306', 'Perum Griya Mandiri Blok B3', 'Air Dingin', 'Bukit Raya'),
  ('140101070707', 'Gilang Saputra', '0812-7307', 'Jl. Srikandi No. 77', 'Delima', 'Tampan'),
  ('140101080808', 'Hani Lestari', '0812-7308', 'Jl. Cempaka No. 15', 'Cinta Raja', 'Sail'),
  ('140101090909', 'Irfan Nugraha', '0812-7309', 'Jl. Kenanga No. 2', 'Sidomulyo Timur', 'Marpoyan Damai'),
  ('140101101010', 'Joko Susilo', '0812-7310', 'Jl. Rambutan No. 12', 'Labuh Baru Barat', 'Payung Sekaki');
INSERT INTO `assistance_records` (`record_date`, `recipient_id`, `status`, `notes`, `funding_source_1_id`, `funding_source_2_id`, `companion_1_id`, `companion_2_id`, `location_1_id`, `location_2_id`, `input_by_user_id`) VALUES
  ('2025-09-01', '1', 'MENUNGGU', 'Keluarga prasejahtera', '1', NULL, '3', NULL, '5', NULL, '2'),
  ('2025-09-01', '2', 'SELESAI', 'Menerima dua jenis bantuan', '2', '1', '1', '3', '1', NULL, '3'),
  ('2025-09-02', '3', 'MENUNGGU', 'Kehilangan pekerjaan', '1', '5', NULL, NULL, '6', '8', '4'),
  ('2025-09-02', '4', 'SELESAI', NULL, '1', NULL, '2', NULL, '4', NULL, '3'),
  ('2025-09-03', '5', 'MENUNGGU', 'Banjir, rumah terdampak', '4', '1', '3', '1', '9', NULL, '2'),
  ('2025-09-03', '6', 'MENUNGGU', 'Dirumahkan dari pekerjaan', '1', '3', NULL, '3', '11', NULL, '4'),
  ('2025-09-04', '7', 'SEDANG_BAGI', 'Anak sekolah 3 orang', '1', NULL, '1', NULL, '3', NULL, '3'),
  ('2025-09-04', '8', 'MENUNGGU', 'Sering sakit, kepala keluarga sakit', '1', '5', '3', '2', '7', '12', '2'),
  ('2025-09-05', '9', 'SELESAI', 'Tinggal sendiri', '1', NULL, '2', NULL, '10', NULL, '5'),
  ('2025-09-05', '10', 'MENUNGGU', 'Penghasilan tidak tetap', '2', '1', NULL, '3', '2', NULL, '4');
INSERT INTO `assistance_items` (`record_id`, `assistance_type_id`, `qty`, `unit`) VALUES
  ('1', '1', '10', 'Kg'),
  ('1', '3', '2', 'Liter'),
  ('2', '5', '300.000', 'Rupiah'),
  ('2', '4', '1', 'Paket'),
  ('3', '1', '5', 'Kg'),
  ('3', '5', '150.000', 'Rupiah'),
  ('3', '3', '1', 'Liter'),
  ('4', '4', '1', 'Paket'),
  ('5', '5', '200.000', 'Rupiah'),
  ('5', '1', '5', 'Kg'),
  ('6', '3', '2', 'Liter'),
  ('6', '5', '100.000', 'Rupiah'),
  ('6', '1', '10', 'Kg'),
  ('7', '4', '1', 'Paket'),
  ('7', '5', '250.000', 'Rupiah'),
  ('8', '1', '10', 'Kg'),
  ('8', '3', '2', 'Liter'),
  ('8', '2', '1', 'Kg'),
  ('9', '4', '1', 'Paket'),
  ('10', '5', '300.000', 'Rupiah'),
  ('10', '1', '5', 'Kg'),
  ('10', '3', '1', 'Liter');
SET FOREIGN_KEY_CHECKS=1;
