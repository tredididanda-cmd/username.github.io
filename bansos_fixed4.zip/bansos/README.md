# Sistem Pendataan & Distribusi Bantuan Sosial

Project demo UAS: dashboard + API.

## Struktur
- `backend/` : FastAPI (Python) di port 8000
- `frontend/`: Static dashboard (jalankan via python http.server)

## Menjalankan Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Jika sebelumnya muncul error **CORS** saat membuka dashboard (misalnya dari
`http://127.0.0.1:5173`), project ini sudah diset untuk mengizinkan origin lokal
umum (5173/5500). Bila Anda memakai port lain, tambahkan origin-nya di
`backend/main.py` pada list `DEV_ALLOWED_ORIGINS`.

## Menjalankan via Docker (opsional)
```bash
docker compose up --build
```
Buka API: http://127.0.0.1:8000

Cek:
- http://127.0.0.1:8000/health
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/distributions

## Menjalankan Frontend
```bash
cd frontend
python -m http.server 5173
```
Buka: http://127.0.0.1:5173

## Endpoint (Frontend ↔ Backend)
Frontend memanggil:
- `GET /distributions` (opsional query: `status`, `kecamatan`, `date_from`, `date_to`, `q`)
- `GET /filters` untuk dropdown (opsional dipakai)
