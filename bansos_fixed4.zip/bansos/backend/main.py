

import os
import re
import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from fastapi import FastAPI, HTTPException, Query, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

APP_DIR = os.path.dirname(__file__)
PROJECT_ROOT = os.path.abspath(os.path.join(APP_DIR, ".."))
SQL_DUMP_PATH = os.path.join(PROJECT_ROOT, "sql_dump_bansos_db.sql")
DATA_STORE_PATH = os.path.join(APP_DIR, "data_store.json")
USERS_STORE_PATH = os.path.join(APP_DIR, "users_store.json")
SESSIONS_PATH = os.path.join(APP_DIR, "sessions_store.json")

app = FastAPI(title="Sistem Pendataan & Distribusi Bantuan Sosial API")

# ---------------------------
# CORS
# ---------------------------
#
# Frontend memanggil API dengan header `Authorization: Bearer ...`, sehingga browser
# akan melakukan *preflight* (OPTIONS). Untuk menghindari error CORS seperti pada
# screenshot ("No 'Access-Control-Allow-Origin' header"), gunakan daftar origin
# yang eksplisit untuk development lokal.
#
# Jika Anda menjalankan frontend dari port lain, tambahkan origin-nya ke list.
DEV_ALLOWED_ORIGINS = [
    "http://127.0.0.1:5173",
    "http://localhost:5173",
    "http://127.0.0.1:5500",
    "http://localhost:5500",
    "http://127.0.0.1:8000",
    "http://localhost:8000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=DEV_ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------
# Helpers: SQL dump parsing
# ---------------------------

def _split_values_groups(values_block: str) -> List[str]:
    """Split VALUES (...) , (...) into list of inside-parens strings, honoring quoted strings."""
    groups: List[str] = []
    depth = 0
    in_str = False
    esc = False
    start: Optional[int] = None

    for i, ch in enumerate(values_block):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == "'":
                in_str = False
        else:
            if ch == "'":
                in_str = True
            elif ch == "(":
                if depth == 0:
                    start = i + 1
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and start is not None:
                    groups.append(values_block[start:i])
                    start = None
    return groups


def _split_row_values(row: str) -> List[str]:
    """Split a single row 'a,b,'c,d'' into list of raw tokens."""
    vals: List[str] = []
    cur: List[str] = []
    in_str = False
    esc = False
    for ch in row:
        if in_str:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == "'":
                in_str = False
        else:
            if ch == "'":
                in_str = True
                cur.append(ch)
            elif ch == ",":
                vals.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
    vals.append("".join(cur).strip())
    return vals


def _parse_token(tok: str) -> Any:
    if tok.upper() == "NULL":
        return None
    # quoted string
    if len(tok) >= 2 and tok[0] == "'" and tok[-1] == "'":
        s = tok[1:-1]
        s = s.replace("\\'", "'").replace("\\\\", "\\")
        return s
    # int/float
    if re.fullmatch(r"-?\d+", tok):
        try:
            return int(tok)
        except Exception:
            return tok
    if re.fullmatch(r"-?\d+\.\d+", tok):
        try:
            return float(tok)
        except Exception:
            return tok
    return tok


INSERT_RE = re.compile(
    r"INSERT\s+INTO\s+`?(?P<table>\w+)`?\s*\((?P<cols>[^)]+)\)\s*VALUES\s*(?P<values>.+?);",
    re.IGNORECASE | re.DOTALL,
)

def load_tables_from_sql(sql_path: str) -> Dict[str, List[Dict[str, Any]]]:
    if not os.path.exists(sql_path):
        raise FileNotFoundError(f"SQL dump not found: {sql_path}")

    sql = open(sql_path, "r", encoding="utf-8", errors="ignore").read()
    tables: Dict[str, List[Dict[str, Any]]] = {}

    for m in INSERT_RE.finditer(sql):
        table = m.group("table")
        cols = [c.strip().strip("`") for c in m.group("cols").split(",")]
        values_block = m.group("values").strip()
        groups = _split_values_groups(values_block)

        for g in groups:
            toks = _split_row_values(g)
            if len(toks) != len(cols):
                # skip malformed rows (robustness for variations)
                continue
            row = {cols[i]: _parse_token(toks[i]) for i in range(len(cols))}
            tables.setdefault(table, []).append(row)
    return tables


def _index_by(rows: List[Dict[str, Any]], key: str) -> Dict[Any, Dict[str, Any]]:
    out: Dict[Any, Dict[str, Any]] = {}
    for r in rows:
        out[r.get(key)] = r
    return out


def _ddmmyyyy(iso: Optional[str]) -> str:
    if not iso:
        return ""
    try:
        # accept YYYY-MM-DD or YYYY-MM-DDTHH:MM...
        d = iso.split("T")[0]
        dt = datetime.strptime(d, "%Y-%m-%d")
        return dt.strftime("%d/%m/%Y")
    except Exception:
        return str(iso)


def build_initial_distributions(tables: Dict[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    recipients = _index_by(tables.get("recipients", []), "id")
    locations = _index_by(tables.get("distribution_locations", []), "id")
    funding = _index_by(tables.get("funding_sources", []), "id")
    atypes = _index_by(tables.get("assistance_types", []), "id")

    items_by_record: Dict[Any, List[Dict[str, Any]]] = {}
    for it in tables.get("assistance_items", []):
        rid = it.get("record_id")
        items_by_record.setdefault(rid, []).append(it)

    rows: List[Dict[str, Any]] = []
    next_id = 1
    for rec in tables.get("assistance_records", []):
        dt = rec.get("distribution_date") or rec.get("record_date") or ""
        rcp = recipients.get(rec.get("recipient_id"), {})
        loc = locations.get(rec.get("location_id") or rec.get("location_1_id") or rec.get("location_2_id"), {})
        fund = funding.get(rec.get("funding_source_id") or rec.get("funding_source_1_id") or rec.get("funding_source_2_id"), {})

        kec = loc.get("kecamatan") or rcp.get("kecamatan")
        name = rcp.get("name") or ""
        nik = rcp.get("nik") or ""

        record_items = items_by_record.get(rec.get("id"), []) or [None]
        for it in record_items:
            bantuan = None
            if it:
                at = atypes.get(it.get("assistance_type_id"), {})
                bantuan = at.get("name")

            rows.append(
                {
                    "id": next_id,
                    "dateISO": dt,
                    "tgl": _ddmmyyyy(dt),
                    "name": name,
                    "nik": nik,
                    "kecamatan": kec,
                    "status": rec.get("status"),
                    "bantuan": bantuan,
                    "sumber_dana": fund.get("name"),
                }
            )
            next_id += 1
    return rows


# ---------------------------
# Persistent stores
# ---------------------------

def _read_json(path: str, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def _write_json(path: str, data) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def init_data_if_needed() -> None:
    if os.path.exists(DATA_STORE_PATH):
        return
    tables = load_tables_from_sql(SQL_DUMP_PATH)
    rows = build_initial_distributions(tables)
    _write_json(DATA_STORE_PATH, {"distributions": rows})

def init_users_if_needed() -> None:
    if os.path.exists(USERS_STORE_PATH):
        return
    # default admin
    users = [
        {
            "id": 1,
            "role": "admin",
            "name": "Administrator",
            "username": "admin",
            "password": "admin123",
            "nik": "0000000000000000",
        }
    ]
    _write_json(USERS_STORE_PATH, {"users": users})


def _load_distributions() -> List[Dict[str, Any]]:
    init_data_if_needed()
    store = _read_json(DATA_STORE_PATH, {"distributions": []})
    return store.get("distributions", [])

def _save_distributions(rows: List[Dict[str, Any]]) -> None:
    _write_json(DATA_STORE_PATH, {"distributions": rows})


def _next_id(records: list[dict]) -> str | int:
    """Generate next primary key for JSON-backed storage.

    If existing IDs are numeric (int or digit strings), continue incrementing.
    If any existing ID is non-numeric (e.g., UUID), generate a UUID string.
    """
    ids = [r.get("id") for r in records or []]
    numeric: list[int] = []
    for _id in ids:
        if _id is None:
            continue
        if isinstance(_id, int):
            numeric.append(_id)
            continue
        if isinstance(_id, str) and _id.isdigit():
            numeric.append(int(_id))
            continue
        # Non-numeric id found -> switch to UUID mode
        return str(uuid.uuid4())
    return (max(numeric) + 1) if numeric else 1


def _load_users() -> List[Dict[str, Any]]:
    init_users_if_needed()
    store = _read_json(USERS_STORE_PATH, {"users": []})
    return store.get("users", [])

def _save_users(users: List[Dict[str, Any]]) -> None:
    _write_json(USERS_STORE_PATH, {"users": users})

def _load_sessions() -> Dict[str, Dict[str, Any]]:
    return _read_json(SESSIONS_PATH, {})

def _save_sessions(sessions: Dict[str, Dict[str, Any]]) -> None:
    _write_json(SESSIONS_PATH, sessions)


# ---------------------------
# Auth models & helpers
# ---------------------------

class RegisterBody(BaseModel):
    name: str = Field(..., min_length=2)
    username: str = Field(..., min_length=3)
    password: str = Field(..., min_length=4)
    nik: str = Field(..., min_length=8, max_length=20)

class LoginBody(BaseModel):
    username: str
    password: str

class DistributionUpsert(BaseModel):
    dateISO: str = Field(..., description="YYYY-MM-DD")
    name: str = Field(..., min_length=2)
    nik: str = Field(..., min_length=8, max_length=20)
    kecamatan: str = Field(..., min_length=2)
    status: str = Field(..., min_length=2)
    bantuan: Optional[str] = None
    sumber_dana: Optional[str] = None


def _validate_nik(nik: str) -> None:
    if not re.fullmatch(r"\d{8,20}", nik or ""):
        raise HTTPException(status_code=400, detail="NIK harus berupa angka 8–20 digit.")

def _require_session(authorization: Optional[str]) -> Dict[str, Any]:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Unauthorized")
    token = authorization.split(" ", 1)[1].strip()
    sessions = _load_sessions()
    sess = sessions.get(token)
    if not sess:
        raise HTTPException(status_code=401, detail="Session tidak valid")
    return sess

def _require_admin(authorization: Optional[str]) -> Dict[str, Any]:
    sess = _require_session(authorization)
    if sess.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    return sess


# ---------------------------
# Health
# ---------------------------

@app.get("/health")
def health():
    return {"ok": True}


# ---------------------------
# Auth endpoints
# ---------------------------

@app.post("/auth/register")
def register(body: RegisterBody):
    _validate_nik(body.nik)
    users = _load_users()

    if any(u["username"].lower() == body.username.lower() for u in users):
        raise HTTPException(status_code=400, detail="Username sudah digunakan.")
    if any(str(u.get("nik")) == str(body.nik) for u in users):
        raise HTTPException(status_code=400, detail="NIK sudah terdaftar.")

    new_id = _next_id(users)
    user = {
        "id": new_id,
        "role": "user",
        "name": body.name,
        "username": body.username,
        "password": body.password,
        "nik": body.nik,
    }
    users.append(user)
    _save_users(users)
    return {"ok": True}

@app.post("/auth/login")
def login(body: LoginBody):
    users = _load_users()
    u = next((x for x in users if x["username"].lower() == body.username.lower() and x["password"] == body.password), None)
    if not u:
        raise HTTPException(status_code=401, detail="Username atau password salah.")

    token = str(uuid.uuid4())
    sessions = _load_sessions()
    sessions[token] = {"user_id": u["id"], "role": u["role"], "name": u["name"], "username": u["username"], "nik": u.get("nik")}
    _save_sessions(sessions)
    return {"token": token, "user": {"id": u["id"], "role": u["role"], "name": u["name"], "username": u["username"], "nik": u.get("nik")}}

@app.post("/auth/logout")
def logout(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.lower().startswith("bearer "):
        return {"ok": True}
    token = authorization.split(" ", 1)[1].strip()
    sessions = _load_sessions()
    if token in sessions:
        sessions.pop(token, None)
        _save_sessions(sessions)
    return {"ok": True}


# ---------------------------
# Data endpoints (compatible with v4 frontend)
# ---------------------------

@app.get("/distributions")
def list_distributions(
    status: Optional[str] = Query(default=None),
    kecamatan: Optional[str] = Query(default=None),
    date_from: Optional[str] = Query(default=None, description="YYYY-MM-DD"),
    date_to: Optional[str] = Query(default=None, description="YYYY-MM-DD"),
    q: Optional[str] = Query(default=None, description="Search name/NIK"),
    nik: Optional[str] = Query(default=None, description="Filter by NIK (for user dashboard)"),
):
    rows = _load_distributions()
    out: List[Dict[str, Any]] = []

    qq = (q or "").strip().lower()
    for r in rows:
        if status and str(r.get("status")) != status:
            continue
        if kecamatan and str(r.get("kecamatan")) != kecamatan:
            continue
        dt = (r.get("dateISO") or "")
        if date_from and dt and str(dt) < date_from:
            continue
        if date_to and dt and str(dt) > date_to:
            continue
        if nik and str(r.get("nik")) != str(nik):
            continue
        if qq:
            if qq not in str(r.get("name","")).lower() and qq not in str(r.get("nik","")).lower():
                continue
        # ensure tgl always present
        rr = dict(r)
        rr["tgl"] = rr.get("tgl") or _ddmmyyyy(rr.get("dateISO"))
        out.append(rr)
    return out


@app.get("/filters")
def get_filters():
    rows = _load_distributions()
    statuses = sorted({r.get("status") for r in rows if r.get("status")})
    kecs = sorted({r.get("kecamatan") for r in rows if r.get("kecamatan")})
    bantuan = sorted({r.get("bantuan") for r in rows if r.get("bantuan")})
    sumber = sorted({r.get("sumber_dana") for r in rows if r.get("sumber_dana")})
    return {"statuses": statuses, "kecamatan": kecs, "bantuan": bantuan, "sumber_dana": sumber}


# ---------------------------
# Admin CRUD distributions
# ---------------------------

@app.post("/distributions")
def create_distribution(body: DistributionUpsert, authorization: Optional[str] = Header(default=None)):
    _require_admin(authorization)
    _validate_nik(body.nik)

    rows = _load_distributions()
    new_id = _next_id(rows)
    row = body.model_dump()
    row["id"] = new_id
    row["tgl"] = _ddmmyyyy(row.get("dateISO"))
    rows.append(row)
    _save_distributions(rows)
    return row

@app.put("/distributions/{dist_id}")
def update_distribution(dist_id: str, body: DistributionUpsert, authorization: Optional[str] = Header(default=None)):
    _require_admin(authorization)
    _validate_nik(body.nik)

    rows = _load_distributions()
    idx = next((i for i, r in enumerate(rows) if str(r.get("id")) == str(dist_id)), None)
    if idx is None:
        raise HTTPException(status_code=404, detail="Data tidak ditemukan.")
    row = body.model_dump()
    # Preserve id as string to support UUID ids as well as numeric ids
    row["id"] = dist_id
    row["tgl"] = _ddmmyyyy(row.get("dateISO"))
    rows[idx] = row
    _save_distributions(rows)
    return row

@app.delete("/distributions/{dist_id}")
def delete_distribution(dist_id: str, authorization: Optional[str] = Header(default=None)):
    _require_admin(authorization)
    rows = _load_distributions()
    new_rows = [r for r in rows if str(r.get("id")) != str(dist_id)]
    if len(new_rows) == len(rows):
        raise HTTPException(status_code=404, detail="Data tidak ditemukan.")
    _save_distributions(new_rows)
    return {"ok": True}


# ---------------------------
# Admin user management
# ---------------------------

@app.get("/users")
def list_users(authorization: Optional[str] = Header(default=None)):
    _require_admin(authorization)
    users = _load_users()
    # hide password
    return [{"id": u["id"], "role": u["role"], "name": u["name"], "username": u["username"], "nik": u.get("nik")} for u in users]

@app.delete("/users/{user_id}")
def delete_user(user_id: str, authorization: Optional[str] = Header(default=None)):
    _require_admin(authorization)
    users = _load_users()
    u = next((x for x in users if str(x.get("id")) == str(user_id)), None)
    if not u:
        raise HTTPException(status_code=404, detail="User tidak ditemukan.")
    if u.get("role") == "admin":
        raise HTTPException(status_code=400, detail="Akun admin tidak dapat dihapus.")
    users = [x for x in users if str(x.get("id")) != str(user_id)]
    _save_users(users)
    return {"ok": True}