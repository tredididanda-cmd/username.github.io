// app.js (v4 base + auth + admin CRUD + user management)
(() => {
  const BACKEND_BASE = "http://127.0.0.1:8000";
  const API = {
    distrib: `${BACKEND_BASE}/distributions`,
    filters: `${BACKEND_BASE}/filters`,
    users: `${BACKEND_BASE}/users`,
    logout: `${BACKEND_BASE}/auth/logout`,
  };

  // ---- auth session ----
  const token = localStorage.getItem("bansos_token") || "";
  const user = (() => {
    try { return JSON.parse(localStorage.getItem("bansos_user") || "null"); } catch { return null; }
  })();

  if (!user || !token) {
    window.location.href = "./index.html";
    return;
  }

  const isAdmin = user.role === "admin";
  const authHeaders = () => ({ "Authorization": `Bearer ${token}` });

  // ---- elements ----
  const el = {
    whoami: document.getElementById("whoami"),
    btnLogout: document.getElementById("btnLogout"),

    titleDash: document.getElementById("titleDash"),
    subtitleDash: document.getElementById("subtitleDash"),
    btnAdd: document.getElementById("btnAdd"),
    thAksi: document.getElementById("thAksi"),

    fStatus: document.getElementById("fStatus"),
    fKecamatan: document.getElementById("fKecamatan"),
    fFrom: document.getElementById("fFrom"),
    fTo: document.getElementById("fTo"),
    btnApply: document.getElementById("btnApply"),
    btnReset: document.getElementById("btnReset"),
    qSearch: document.getElementById("qSearch"),
    tbody: document.getElementById("tbody"),
    totalDist: document.getElementById("totalDist"),

    chartStatus: document.getElementById("chartStatus"),
    chartAid: document.getElementById("chartAid"),

    userMgmtCard: document.getElementById("userMgmtCard"),
    tbodyUsers: document.getElementById("tbodyUsers"),

    // modal
    modal: document.getElementById("modalDist"),
    modalTitle: document.getElementById("modalTitle"),
    modalMsg: document.getElementById("modalMsg"),
    distId: document.getElementById("distId"),
    distDate: document.getElementById("distDate"),
    distStatus: document.getElementById("distStatus"),
    distName: document.getElementById("distName"),
    distNik: document.getElementById("distNik"),
    distKec: document.getElementById("distKec"),
    distAid: document.getElementById("distAid"),
    distFund: document.getElementById("distFund"),
    btnSave: document.getElementById("btnSave"),
  };

  // ---- init UI ----
  el.whoami.textContent = `${user.role.toUpperCase()}: ${user.name}`;
  el.titleDash.textContent = isAdmin ? "Dashboard Admin" : "Dashboard Pengguna";
  el.subtitleDash.textContent = isAdmin
    ? "Kelola data distribusi (input / edit / delete) dan lihat manajemen user."
    : `Lihat data distribusi bantuan untuk NIK: ${user.nik}`;

  if (isAdmin) {
    el.btnAdd.classList.remove("d-none");
    el.thAksi.classList.remove("d-none");
    el.userMgmtCard.classList.remove("d-none");
  }

  // ---- helpers ----
  function escapeHtml(s) {
    return String(s ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function isoFromInput(s) {
    const v = (s || "").trim();
    if (!v) return "";
    // YYYY-MM-DD
    const m1 = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (m1) {
      return `${m1[1]}-${m1[2].padStart(2, "0")}-${m1[3].padStart(2, "0")}`;
    }
    // DD/MM/YYYY
    const m2 = v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (m2) {
      return `${m2[3]}-${m2[2].padStart(2, "0")}-${m2[1].padStart(2, "0")}`;
    }
    // DD-MM-YYYY
    const m3 = v.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
    if (m3) {
      return `${m3[3]}-${m3[2].padStart(2, "0")}-${m3[1].padStart(2, "0")}`;
    }
    return "";
  }

  function statusBadge(status) {
    const s = String(status || "").toUpperCase();
    let cls = "text-bg-secondary";
    if (s.includes("MENUNGGU")) cls = "text-bg-warning text-dark";
    else if (s.includes("SELESAI")) cls = "text-bg-success";
    else if (s.includes("TOLAK") || s.includes("GAGAL")) cls = "text-bg-danger";
    else if (s.includes("PROSES") || s.includes("SEDANG")) cls = "text-bg-info text-dark";
    return `<span class="badge ${cls}">${escapeHtml(status || "-")}</span>`;
  }

  async function fetchJSON(url, opts = {}) {
    const res = await fetch(url, opts);
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const msg = (data && data.detail) ? data.detail : `HTTP ${res.status}`;
      throw new Error(msg);
    }
    return data;
  }

  function buildQuery() {
    const p = new URLSearchParams();
    if (el.fStatus.value) p.set("status", el.fStatus.value);
    if (el.fKecamatan.value) p.set("kecamatan", el.fKecamatan.value);
    if (el.fFrom.value) p.set("date_from", el.fFrom.value);
    if (el.fTo.value) p.set("date_to", el.fTo.value);
    const q = (el.qSearch.value || "").trim();
    if (q) p.set("q", q);

    // user dashboard is locked by NIK
    if (!isAdmin && user.nik) p.set("nik", user.nik);
    return p.toString();
  }

  // ---- charts ----
  let chartStatus = null;
  let chartAid = null;

  function drawCharts(rows) {
    const byStatus = {};
    const byAid = {};
    for (const r of rows) {
      const st = r.status || "UNKNOWN";
      byStatus[st] = (byStatus[st] || 0) + 1;
      const aid = r.bantuan || "Tidak ada";
      byAid[aid] = (byAid[aid] || 0) + 1;
    }

    const statusLabels = Object.keys(byStatus);
    const statusVals = statusLabels.map(k => byStatus[k]);

    const aidLabels = Object.keys(byAid);
    const aidVals = aidLabels.map(k => byAid[k]);

    el.totalDist.textContent = String(rows.length);

    if (chartStatus) chartStatus.destroy();
    if (chartAid) chartAid.destroy();

    chartStatus = new Chart(el.chartStatus, {
      type: "bar",
      data: { labels: statusLabels, datasets: [{ label: "Jumlah", data: statusVals }] },
      options: { responsive: true, plugins: { legend: { display: false } } }
    });

    chartAid = new Chart(el.chartAid, {
      type: "bar",
      data: { labels: aidLabels, datasets: [{ label: "Jumlah", data: aidVals }] },
      options: { responsive: true, plugins: { legend: { display: false } } }
    });
  }

  // ---- table render ----
  function renderTable(rows) {
    el.tbody.innerHTML = "";
    if (!rows.length) {
      el.tbody.innerHTML = `<tr><td colspan="${isAdmin ? 8 : 7}" class="text-muted py-4 text-center">Tidak ada data.</td></tr>`;
      return;
    }

    for (const r of rows) {
      const tgl = r.tgl || "";
      const aksi = isAdmin
        ? `<td>
            <div class="btn-group btn-group-sm">
              <button class="btn btn-outline-primary" data-act="edit" data-id="${r.id}">Edit</button>
              <button class="btn btn-outline-danger" data-act="del" data-id="${r.id}">Hapus</button>
            </div>
          </td>`
        : "";

      el.tbody.insertAdjacentHTML("beforeend",
        `<tr>
          <td>${escapeHtml(tgl)}</td>
          <td>${escapeHtml(r.name)}</td>
          <td class="font-monospace">${escapeHtml(r.nik)}</td>
          <td>${escapeHtml(r.kecamatan)}</td>
          <td>${statusBadge(r.status)}</td>
          <td>${escapeHtml(r.bantuan ?? "-")}</td>
          <td>${escapeHtml(r.sumber_dana ?? "-")}</td>
          ${aksi}
        </tr>`
      );
    }
  }

  // ---- load data ----
  let lastRows = [];

  async function loadFilters() {
    const data = await fetchJSON(API.filters);
    // fill status
    const statusOptions = ['<option value="">(Semua)</option>']
      .concat((data.statuses || []).map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`))
      .join("");
    el.fStatus.innerHTML = statusOptions;

    const kecOptions = ['<option value="">(Semua)</option>']
      .concat((data.kecamatan || []).map(k => `<option value="${escapeHtml(k)}">${escapeHtml(k)}</option>`))
      .join("");
    el.fKecamatan.innerHTML = kecOptions;
  }

  async function loadRows() {
    const qs = buildQuery();
    const url = qs ? `${API.distrib}?${qs}` : API.distrib;
    lastRows = await fetchJSON(url);
    renderTable(lastRows);
    drawCharts(lastRows);
  }

  // ---- admin: modal ----
  const bsModal = el.modal ? new bootstrap.Modal(el.modal) : null;

  function modalError(msg) {
    el.modalMsg.textContent = msg;
    el.modalMsg.classList.remove("d-none");
  }
  function modalClearError() {
    el.modalMsg.classList.add("d-none");
  }

  function openCreate() {
    el.modalTitle.textContent = "Input Distribusi";
    el.distId.value = "";
    el.distDate.value = "";
    el.distStatus.value = "";
    el.distName.value = "";
    el.distNik.value = "";
    el.distKec.value = "";
    el.distAid.value = "";
    el.distFund.value = "";
    modalClearError();
    bsModal.show();
  }

  function openEdit(row) {
    el.modalTitle.textContent = "Edit Distribusi";
    el.distId.value = row.id;
    el.distDate.value = row.dateISO || "";
    el.distStatus.value = row.status || "";
    el.distName.value = row.name || "";
    el.distNik.value = row.nik || "";
    el.distKec.value = row.kecamatan || "";
    el.distAid.value = row.bantuan || "";
    el.distFund.value = row.sumber_dana || "";
    modalClearError();
    bsModal.show();
  }

  function validateNik(nik) {
    return /^\d{8,20}$/.test(String(nik || "").trim());
  }

  async function saveModal() {
    modalClearError();
    // id can be numeric OR UUID string depending on stored data
    const id = (el.distId.value || "").trim() || null;
    const body = {
      dateISO: isoFromInput(el.distDate.value),
      status: el.distStatus.value.trim(),
      name: el.distName.value.trim(),
      nik: el.distNik.value.trim(),
      kecamatan: el.distKec.value.trim(),
      bantuan: el.distAid.value.trim() || null,
      sumber_dana: el.distFund.value.trim() || null,
    };

    if (!body.dateISO) return modalError("Tanggal harus format YYYY-MM-DD (atau pilih date input).");
    if (!validateNik(body.nik)) return modalError("NIK harus angka 8–20 digit.");
    if (!body.name) return modalError("Nama wajib diisi.");
    if (!body.kecamatan) return modalError("Kecamatan wajib diisi.");
    if (!body.status) return modalError("Status wajib diisi.");

    try {
      if (!id) {
        await fetchJSON(API.distrib, {
          method: "POST",
          headers: { "Content-Type": "application/json", ...authHeaders() },
          body: JSON.stringify(body),
        });
      } else {
        await fetchJSON(`${API.distrib}/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json", ...authHeaders() },
          body: JSON.stringify(body),
        });
      }
      bsModal.hide();
      await loadFilters();
      await loadRows();
    } catch (e) {
      modalError(e.message || String(e));
    }
  }

  async function deleteRow(id) {
    if (!confirm("Hapus data distribusi ini?")) return;
    try {
      await fetchJSON(`${API.distrib}/${id}`, {
        method: "DELETE",
        headers: authHeaders(),
      });
      await loadFilters();
      await loadRows();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  // ---- admin: user mgmt ----
  async function loadUsers() {
    if (!isAdmin) return;
    const users = await fetchJSON(API.users, { headers: authHeaders() });
    el.tbodyUsers.innerHTML = "";
    for (const u of users) {
      const canDel = u.role !== "admin";
      const aksi = canDel
        ? `<button class="btn btn-outline-danger btn-sm" data-uact="del" data-uid="${u.id}">Hapus</button>`
        : `<span class="text-muted small">-</span>`;
      el.tbodyUsers.insertAdjacentHTML("beforeend", `
        <tr>
          <td><span class="badge text-bg-secondary">${escapeHtml(u.role)}</span></td>
          <td>${escapeHtml(u.name)}</td>
          <td class="font-monospace">${escapeHtml(u.username)}</td>
          <td class="font-monospace">${escapeHtml(u.nik || "")}</td>
          <td>${aksi}</td>
        </tr>
      `);
    }
  }

  async function deleteUser(uid) {
    if (!confirm("Hapus user ini?")) return;
    try {
      await fetchJSON(`${API.users}/${uid}`, { method: "DELETE", headers: authHeaders() });
      await loadUsers();
    } catch (e) {
      alert(e.message || String(e));
    }
  }

  // ---- events ----
  el.btnApply.addEventListener("click", loadRows);
  el.btnReset.addEventListener("click", async () => {
    el.fStatus.value = "";
    el.fKecamatan.value = "";
    el.fFrom.value = "";
    el.fTo.value = "";
    el.qSearch.value = "";
    await loadRows();
  });
  el.qSearch.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      loadRows();
    }
  });

  el.btnLogout.addEventListener("click", async () => {
    try {
      await fetchJSON(API.logout, { method: "POST", headers: authHeaders() });
    } catch {}
    localStorage.removeItem("bansos_token");
    localStorage.removeItem("bansos_user");
    window.location.href = "./index.html";
  });

  if (isAdmin) {
    el.btnAdd.addEventListener("click", openCreate);

    el.tbody.addEventListener("click", (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      const act = btn.getAttribute("data-act");
      const id = (btn.getAttribute("data-id") || "").trim();
      if (!act || !id) return;
      const row = lastRows.find(r => String(r.id) === id);
      if (act === "edit" && row) openEdit(row);
      if (act === "del") deleteRow(id);
    });

    el.btnSave.addEventListener("click", saveModal);

    el.tbodyUsers.addEventListener("click", (e) => {
      const btn = e.target.closest("button");
      if (!btn) return;
      const act = btn.getAttribute("data-uact");
      const uid = (btn.getAttribute("data-uid") || "").trim();
      if (act === "del" && uid) deleteUser(uid);
    });
  }

  // ---- boot ----
  (async () => {
    try {
      await loadFilters();
      await loadRows();
      await loadUsers();
    } catch (e) {
      console.error(e);
      alert("Gagal memuat data: " + (e.message || String(e)));
    }
  })();
})();
