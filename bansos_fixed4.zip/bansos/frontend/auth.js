// auth.js
(() => {
  const BASE = "http://127.0.0.1:8000";

  function showMsg(msg) {
    const el = document.getElementById("msg");
    if (!el) return;
    el.textContent = msg;
    el.classList.remove("d-none");
  }
  function hideMsg() {
    const el = document.getElementById("msg");
    if (!el) return;
    el.classList.add("d-none");
  }

  async function postJSON(url, body) {
    const res = await fetch(url, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.detail || "Terjadi kesalahan.");
    }
    return data;
  }

  // LOGIN
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      hideMsg();
      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value;
      try {
        const data = await postJSON(`${BASE}/auth/login`, { username, password });
        localStorage.setItem("bansos_token", data.token);
        localStorage.setItem("bansos_user", JSON.stringify(data.user));
        window.location.href = "./dashboard.html";
      } catch (err) {
        showMsg(err.message || String(err));
      }
    });
    return;
  }

  // REGISTER
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      hideMsg();
      const name = document.getElementById("name").value.trim();
      const nik = document.getElementById("nik").value.trim();
      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value;

      try {
        await postJSON(`${BASE}/auth/register`, { name, nik, username, password });
        // auto login after register
        const data = await postJSON(`${BASE}/auth/login`, { username, password });
        localStorage.setItem("bansos_token", data.token);
        localStorage.setItem("bansos_user", JSON.stringify(data.user));
        window.location.href = "./dashboard.html";
      } catch (err) {
        showMsg(err.message || String(err));
      }
    });
  }
})();
